package github.game;

public class Pub extends Building{

    @Override
    public void update(InputHandler inputHandler, Renderer renderer) {
        super.update(inputHandler, renderer);
    }
}
