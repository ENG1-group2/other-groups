package github.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.Vector2;

import java.awt.*;
import java.lang.reflect.Method;

import static github.game.GameMap.CELL_HEIGHT;
import static github.game.GameMap.CELL_WIDTH;
import static github.game.GameWindow.HEIGHT;
import static github.game.GameWindow.WIDTH;

public class Game {

    private int timeLeft;
    private float timer;
    private boolean isPaused;
    private GameMap gameMap;
    private UI ui;
    private int buildingCount;
    private Building buildingPlaceSelected;
    private Renderer renderer;
    private InputHandler inputHandler;

    public Game(Renderer renderer, InputHandler inputHandler) {
        this.renderer = renderer;
        this.inputHandler = inputHandler;
        this.gameMap = new GameMap(this);
    }

    public void create() {
        timeLeft = 300;
        timer = 0f;
        isPaused = true;
        ui = new UI();
        buildingCount = 0;
        buildingPlaceSelected = null;
    }

    public void render() {
        handleInput();

        if (!isPaused && timeLeft > 0){
            update(Gdx.graphics.getDeltaTime());
        }

    }

    private void handleInput(){
        if (Gdx.input.isKeyJustPressed(Keys.SPACE)){
            togglePause();
        }

        if (inputHandler.getMouseClicked()) {
            Vector2 worldPos = inputHandler.getMousePos(); // mousepos in world coordinates
            handleMapCellClick(worldPos.x, worldPos.y);
        }

        if (Gdx.input.isKeyJustPressed(Keys.NUM_1)){
            buildingPlaceSelected = new Pub();
            System.out.println("Current Building:" + buildingPlaceSelected);
        }

        if (Gdx.input.isKeyJustPressed(Keys.NUM_2)){
            buildingPlaceSelected = new Halls();
            System.out.println("Current Building:" + buildingPlaceSelected);
        }

        if (Gdx.input.isKeyJustPressed(Keys.NUM_3)){
            buildingPlaceSelected = new Restaurant();
            System.out.println("Current Building:" + buildingPlaceSelected);
        }

        if (Gdx.input.isKeyJustPressed(Keys.NUM_4)){
            buildingPlaceSelected = new LectureHall();
            System.out.println("Current Building:" + buildingPlaceSelected);
        }

        if (Gdx.input.isKeyJustPressed(Keys.NUM_5)){
            buildingPlaceSelected = new Gym();
            System.out.println("Current Building:" + buildingPlaceSelected);
        }
    }

    private void update(float deltaTime){
        timer += deltaTime;

        if (timer >= 1f) {
            timeLeft--;
            timer -= 1f;
        }
    }

    public void togglePause(){
        isPaused = !isPaused;
    }

    private void handleMapCellClick(float worldX, float worldY) {
        // converter for ease of use translation
        int cellX = (int) (worldX / GameMap.CELL_WIDTH);
        int cellY = (int) (worldY / GameMap.CELL_HEIGHT);

        if (cellX < 0 || cellX >= gameMap.cells.length || cellY < 0 || cellY >= gameMap.cells[0].length) {
            System.out.println("Clicked position is out of bounds.");
            return;
        }

        Cell cell = gameMap.cells[cellX][cellY];

        // this one calls the handleBuildingPlaceBtnClick with the cell and selected building type
        handleBuildingPlaceBtnClick(cell, buildingPlaceSelected);
    }

    public void handleBuildingPlaceBtnClick(Cell cell, Building buildingType) {
        if (buildingType == null) {
            System.out.println("No building type selected for placement.");
            return;
        }

        // check if the cell is free
        if (gameMap.getCanPlace(buildingType, cell)) {

            if (gameMap.placeBuilding(buildingType, cell)) {
                System.out.println("Building placed successfully at cell (" + cell.pos.x + ", " + cell.pos.y + ").");
                buildingCount++;
                buildingPlaceSelected = null;
            } else {
                System.out.println("Cant place building at cell (" + cell.pos.x + ", " + cell.pos.y + ").");
            }
        } else {
            System.out.println("Cell (" + cell.pos.x + ", " + cell.pos.y + ") is not free for building placement.");
        }
    }
    public int getTimeLeft() {
        return timeLeft;
    }

    public boolean getIsPaused() {
        return isPaused;
    }

    public int getBuildingCount() {
        return buildingCount;
    }

    public Building getBuildingPlaceSelected() {
        return buildingPlaceSelected;
    }

    public GameMap getGameMap() {
        return gameMap;
    }
}
