package github.game;

public class Restaurant extends Building{

    @Override
    public void update(InputHandler inputHandler, Renderer renderer) {
        super.update(inputHandler, renderer);
    }
}
