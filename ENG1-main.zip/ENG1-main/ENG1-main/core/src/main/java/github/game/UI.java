package github.game;

public class UI {
    Entity[] uiEntities;

    public void update(InputHandler inputHandler, Renderer renderer){

    }
}
