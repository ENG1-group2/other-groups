package github.game;

public class LectureHall extends Building{

    @Override
    public void update(InputHandler inputHandler, Renderer renderer) {
        super.update(inputHandler, renderer);
    }
}
