package github.game;

public class Map {

    Building[] placedBuildings;
    Cell[] cells;
    Entity[] obstacles;

    public void update(InputHandler inputHandler, Renderer renderer){

    }
}
