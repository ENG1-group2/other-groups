package github.game;

public class Halls extends Building{

    @Override
    public void update(InputHandler inputHandler, Renderer renderer) {
        super.update(inputHandler, renderer);
    }
}
