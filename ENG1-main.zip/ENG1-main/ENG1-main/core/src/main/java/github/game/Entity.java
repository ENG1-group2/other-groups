package github.game;

public abstract class Entity {

    public abstract void update(Renderer renderer, InputHandler inputHandler);

}
