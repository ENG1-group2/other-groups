package github.game;

public class Gym extends Building{

    @Override
    public void update(InputHandler inputHandler, Renderer renderer) {
        super.update(inputHandler, renderer);
    }
}
