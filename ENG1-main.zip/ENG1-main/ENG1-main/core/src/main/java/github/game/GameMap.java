package github.game;

import java.awt.*;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;

public class GameMap {

    public static final int CELL_WIDTH = 20;
    public static final int CELL_HEIGHT = 20;

    ArrayList<Building> placedBuildings;
    Cell[][] cells;
    Entity[] obstacles;
    Game game;


    public GameMap(Game game) {
        placedBuildings = new ArrayList<>();
        cells = new Cell[64][36];
        this.game = game;

        for (int x = 0; x < cells.length; x++) {
            for (int y = 0; y < cells[0].length; y++) {
                cells[x][y] = new Cell(false, new Point(x * CELL_WIDTH, y * CELL_HEIGHT)); // instantiate each Cell
            }
        }
    }

    public void update(InputHandler inputHandler, Renderer renderer){

    }

    public boolean getCanPlace(Building building, Cell cellPos) {

        if (cellPos.isOccupied() || cellPos.isRestricted()) {
            return false;
        }
        return true;
    }

    public boolean placeBuilding(Building building, Cell cellPos) {

        if (getCanPlace(building, cellPos)) {
            cellPos.setOccupied(true, building);
            placedBuildings.add(building);

            return true;
        } else {
            return false; //cant place
        }
    }

    public boolean removeBuilding(Cell cell) {
        if (!cell.isOccupied()) {
            System.out.println("No building to remove at this cell.");
            return false;
        }

        Building buildingToRemove = cell.getOccupyingBuilding();
        if (buildingToRemove != null) {
            placedBuildings.remove(buildingToRemove);  // remove from placed buildings
            cell.setOccupied(false, null);             // free the cell
            System.out.println("Building removed from cell (" + cell.pos.x + ", " + cell.pos.y + ").");
            return true;
        }
        return false;
    }
}
