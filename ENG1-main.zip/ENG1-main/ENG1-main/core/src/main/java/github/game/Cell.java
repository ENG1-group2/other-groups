package github.game;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.Vector2;

import java.awt.*;

public class Cell extends Entity{
    Point pos;
    @Override
    public void update(Renderer renderer, InputHandler inputHandler) {

    }

    private Building occupyingBuilding;
    private boolean occupied;
    private boolean restricted;

    public Cell(boolean restricted, Point pos) {
        this.pos = pos;
        this.occupied = false;
        this.restricted = restricted;
    }


    public void render(Renderer renderer) {
        Vector2 rectPos = new Vector2(pos.x, pos.y);
        Color color = occupied ? Color.BLUE : Color.GREEN; // Blue if occupied, otherwise green
        renderer.drawRect(rectPos, new Vector2(18, 18), color);
    }


    public void setOccupied(boolean occupied, Building building) {
        this.occupied = occupied;
        this.occupyingBuilding = occupied ? building : null;
    }

    public Building getOccupyingBuilding() {
        return occupyingBuilding;
    }

    // check if the cell has any restrictions like for obstacles
    public boolean isRestricted() {
        return restricted;
    }

    //same as above but like for stuff player has placed
    public boolean isOccupied() {
        return occupied;
    }

    // marks cell as occupied when placing a building
    public void setOccupied(boolean occupied) {
        this.occupied = occupied;
    }
}
