package github.game;

public class Building {
    Cell[] relCellsUsed;

    public void update(InputHandler inputHandler, Renderer renderer){

    }

}
